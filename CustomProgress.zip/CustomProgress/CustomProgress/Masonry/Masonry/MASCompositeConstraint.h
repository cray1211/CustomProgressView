#import "MASConstraint.h"
#import "MASUtilities.h"
@interface MASCompositeConstraint : MASConstraint
- (id)initWithChildren:(NSArray *)children;
@end
