#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface CustomProgressView : UIView
@property (nonatomic ,strong) UIColor *upViewColor;
@property (nonatomic ,strong) UIColor *bellowViewColor;
@property (nonatomic ,assign) CGFloat progress;
@property (nonatomic ,strong) UIImageView *vsImgV;
@property (nonatomic ,assign) BOOL hiddenValueView;
@property (nonatomic ,strong) NSString *leftValue;
@property (nonatomic ,strong) NSString *rightValue;
@property (nonatomic ,strong) UILabel *leftValueView;
@property (nonatomic ,strong) UILabel *rightValueView;
@end
NS_ASSUME_NONNULL_END
