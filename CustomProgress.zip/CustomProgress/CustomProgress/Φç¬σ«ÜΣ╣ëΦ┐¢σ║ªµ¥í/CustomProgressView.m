#import "CustomProgressView.h"
#import "Masonry.h"
#define VIEW_WIDTH [UIScreen mainScreen].bounds.size.width
#define ScaleW(width)  width*VIEW_WIDTH/375
#define systemFont(x) [UIFont systemFontOfSize:x]
@interface CustomProgressView()
@property (nonatomic ,strong) UIView *upView;
@property (nonatomic ,strong) UIView *bellowView;
@end
@implementation CustomProgressView
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}
- (void) addChildrenViews{
    [self addSubview:self.bellowView];
    [self addSubview:self.upView];
    [self addSubview:self.leftValueView];
    [self addSubview:self.rightValueView];
    [self addSubview:self.vsImgV];
    self.bellowView.backgroundColor = UIColor.redColor;
    self.upView.backgroundColor =UIColor.greenColor;
    self.leftValueView.text = @"50%";
    self.rightValueView.text = @"50%";
    self.progress = 0.5;
    
}
- (void)setProgress:(CGFloat)progress{
    _progress = progress;
    if (progress > 1) {
        progress = 1;
    }
    if (progress < 0) {
        progress = 0;
    }
    self.leftValueView.text = [NSString stringWithFormat:@"%@%%", [self noroundingStringWith:progress * 100 afterPointNumber:2]];
    self.rightValueView.text = [NSString stringWithFormat:@"%@%%", [self noroundingStringWith:(1 - progress) * 100 afterPointNumber:2]];
    CGFloat scawle = 0;
    if (self.bounds.size.width > 0) {
//        scawle = self.bounds.size.height / self.bounds.size.width;
    }
    [UIView animateWithDuration:0.5 animations:^{
        [self.upView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.top.bottom.mas_equalTo(self);
            make.width.mas_equalTo(self.bellowView.mas_width).multipliedBy(self.progress + scawle);
        }];
        [self.vsImgV mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(ScaleW(17));
            make.height.mas_equalTo(ScaleW(10));
            make.centerY.mas_equalTo(self.upView);
            make.centerX.mas_equalTo(self.upView.mas_right);
        }];
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
//        UIBezierPath *path = [UIBezierPath bezierPath];
//        [path moveToPoint:CGPointMake(0, 0)];
//        [path addLineToPoint:CGPointMake(self.upView.bounds.size.width, 0)];
//        [path addLineToPoint:CGPointMake(self.upView.bounds.size.width - self.upView.bounds.size.height, self.upView.bounds.size.height)];
//        [path addLineToPoint:CGPointMake(0, self.upView.bounds.size.height)];
//        [path addLineToPoint:CGPointMake(0, 0)];
//        CAShapeLayer *shapLayer = [CAShapeLayer layer];
//        shapLayer.frame = self.upView.bounds;
//        shapLayer.path = path.CGPath;
//        self.upView.layer.mask = shapLayer;
    }];
}
- (void)setUpViewColor:(UIColor *)upViewColor{
    _upViewColor = upViewColor;
    self.upView.backgroundColor = upViewColor;
}
- (void)setBellowViewColor:(UIColor *)bellowViewColor{
    _bellowViewColor = bellowViewColor;
    self.bellowView.backgroundColor = bellowViewColor;
}
- (void)setLeftValue:(NSString *)leftValue{
    self.leftValueView.text = leftValue;
}
- (void)setRightValue:(NSString *)rightValue{
    self.rightValueView.text = rightValue;
}
- (void)layoutSubviews{
    [super layoutSubviews];
    [self.bellowView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.bottom.right.mas_equalTo(self);
    }];
    [self.upView mas_makeConstraints:^(MASConstraintMaker *make) {
        CGFloat scawle = 0;
        if (self.bounds.size.width > 0) {
            scawle = self.bounds.size.height / self.bounds.size.width;
        }
        make.left.top.bottom.mas_equalTo(self);
        make.width.mas_equalTo(self.mas_width).multipliedBy(self.progress + scawle);
    }];
    [self.leftValueView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self).offset(ScaleW(20));
        make.centerY.mas_equalTo(self.bellowView);
    }];
    [self.rightValueView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self).offset(ScaleW(-20));
        make.centerY.mas_equalTo(self.bellowView);
    }];
    [self layoutIfNeeded];
}
- (UIView *)bellowView{
    if (!_bellowView) {
        _bellowView = [[UIView alloc] init];
        _bellowView.backgroundColor = UIColor.redColor;
    }
    return _bellowView;
}
- (UIView *)upView{
    if (!_upView) {
        _upView = [[UIView alloc] init];
        _upView.backgroundColor = UIColor.greenColor;
    }
    return _upView;
}
- (UILabel *)leftValueView{
    if (!_leftValueView) {
        _leftValueView = [[UILabel alloc] init];
        _leftValueView.text = @"0.5";
        _leftValueView.font = systemFont(14);
        _leftValueView.textColor = UIColor.whiteColor;
    }
    return _leftValueView;
}
- (UILabel *)rightValueView{
    if (!_rightValueView) {
        _rightValueView = [[UILabel alloc] init];
        _rightValueView.text = @"0.5";
        _rightValueView.font = systemFont(14);
        _rightValueView.textColor = UIColor.whiteColor;
    }
    return _rightValueView;
}
- (UIImageView *)vsImgV{
    if (!_vsImgV) {
        _vsImgV = [[UIImageView alloc] init];
        _vsImgV.image = [UIImage imageNamed:@"vs-1"];
    }
    return _vsImgV;
}
- (void)setHiddenValueView:(BOOL)hiddenValueView{
    self.leftValueView.hidden = self.rightValueView.hidden = hiddenValueView;
}


-(NSString *)noroundingStringWith:(double)price afterPointNumber:(NSInteger)point;
{
    NSString *format = [NSString stringWithFormat:@"%%.%ldf",point + 1];
    NSString *string =  [NSString stringWithFormat:format,price];
    NSArray *array = [string componentsSeparatedByString:@"."];
    if (array.count < 2) {
        return [NSString stringWithFormat:@"%ld",(long)price];
    }
    NSString *str = array.lastObject;
    if (str.integerValue == 0) {
        return array.firstObject;
    }
    NSString *newString = [str substringToIndex:point];
    newString = [self deleteLastZeroWithString:newString];
    newString = [NSString stringWithFormat:@"%@.%@",array.firstObject,newString];
    return newString ;
}
    
-(NSString *)deleteLastZeroWithString:(NSString *)string
{
    if ([string hasSuffix:@"0"]) {
        return [self deleteLastZeroWithString:[string substringToIndex:string.length - 1]];
    }else{
        return string;
    }
}
@end
