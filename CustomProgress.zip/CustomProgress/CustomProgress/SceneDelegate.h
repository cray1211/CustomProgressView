//
//  SceneDelegate.h
//  CustomProgress
//
//  Created by mac on 2021/1/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

