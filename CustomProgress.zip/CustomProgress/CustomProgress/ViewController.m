//
//  ViewController.m
//  CustomProgress
//
//  Created by mac on 2021/1/22.
//

#import "ViewController.h"
#import "CustomProgressView.h"
#import "Masonry.h"
@interface ViewController ()
@property (nonatomic ,strong) CustomProgressView *progressView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = UIColor.orangeColor;
    
    
    
    
    [self.view addSubview:self.progressView];
    [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(35);
        make.right.mas_equalTo(self.view).offset(-35);
        make.height.mas_equalTo(15);
        make.centerY.mas_equalTo(self.view).offset(-40);
    }];
    
    
    
    
    
    [NSTimer scheduledTimerWithTimeInterval:2 repeats:YES block:^(NSTimer * _Nonnull timer) {
        CGFloat progress = (arc4random()%100 + 20) / 120.00;
        self.progressView.progress = progress;
    }];
}






- (CustomProgressView *)progressView{
    if (!_progressView) {
        _progressView = [[CustomProgressView alloc] init];
        _progressView.upViewColor = UIColor.greenColor;
        _progressView.bellowViewColor = UIColor.redColor;
        _progressView.vsImgV.hidden = YES;
        _progressView.layer.cornerRadius = 7.5;
        _progressView.layer.masksToBounds = YES;
    }
    return _progressView;
}

@end
